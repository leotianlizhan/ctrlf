# ctrlf
Ctrl F functionality using live camera feed, powered by Google Mobile Vision API

# Play Store
https://play.google.com/store/apps/details?id=com.zhan.leo.ctrlf
